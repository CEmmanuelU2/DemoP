package com.demo.tienda.models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UsuarioTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }

    @Test
    void getId() {
    }

    @Test
    void getNombre() {
    }

    @Test
    void getApellido() {
    }

    @Test
    void getEmail() {
    }

    @Test
    void getTelefono() {
    }

    @Test
    void getPassword() {
    }

    @Test
    void setId() {
    }

    @Test
    void setNombre() {
    }

    @Test
    void setApellido() {
    }

    @Test
    void setEmail() {
    }

    @Test
    void setTelefono() {
    }

    @Test
    void setPassword() {
    }
}