package com.demo.tienda.controllers;

import com.demo.tienda.dto.UsuarioDTO;
import com.demo.tienda.dao.UsuarioDao;
import com.demo.tienda.models.Usuario;
import com.demo.tienda.util.JWTUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class AuthController {

    @Autowired
    private UsuarioDao usuarioDao;

    @Autowired
    private JWTUtil Utils;

    @PostMapping("api/login")
    public ResponseEntity<String> login(@RequestBody UsuarioDTO usuarioDTO) {
        // Convertir DTO a entidad
        Usuario usuario = new Usuario();
        usuario.setEmail(usuarioDTO.getEmail());
        usuario.setPassword(usuarioDTO.getPassword());

        // Verifica las credenciales del usuario en la base de datos
        Usuario usuarioLogueado = usuarioDao.obtenerUsuarioPorCredenciales(usuario);

        if (usuarioLogueado != null) {
            // Crea un token JWT con el ID del usuario y su correo electrónico
            String tokenJwt = Utils.create(String.valueOf(usuarioLogueado.getId()), usuarioLogueado.getEmail());
            // Retorna el token JWT con un código de estado 200 OK
            return ResponseEntity.ok(tokenJwt);
        }

        // Retorna un mensaje de error con un código de estado 401 Unauthorized
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Credenciales inválidas");
    }
}