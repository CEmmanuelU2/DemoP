package com.demo.tienda.controllers;

public class UnauthorizedException extends Throwable {
    public UnauthorizedException(String tokenInválido) {
    }
}
