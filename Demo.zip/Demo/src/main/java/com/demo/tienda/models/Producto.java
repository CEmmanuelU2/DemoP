package com.demo.tienda.models;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

// Marca esta clase como una entidad JPA que se mapea a una tabla en la base de datos
@Entity
// Especifica el nombre de la tabla en la base de datos (opcional)
@Table(name = "productosdemo")
// Genera automáticamente métodos toString(), equals() y hashCode() usando Lombok
@ToString
@EqualsAndHashCode
@Getter
@Setter
@NoArgsConstructor
public class Producto {

    // Marca el campo como la clave primaria de la entidad
    @Id
    // Indica que el valor de la clave primaria se generará automáticamente
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "precio")
    private double precio;

    @Column(name = "stock")
    private int stock;

    // Constructor con parámetros
    public Producto(Long id, String nombre, String descripcion, double precio, int stock) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.stock = stock;
    }
}