package com.demo.tienda.services;

import com.demo.tienda.models.Producto;
import java.util.List;

public interface ProductService {
    List<Producto> getAllProducts();
    Producto getProductById(Long id);
    Producto createProduct(Producto producto);
    Producto updateProduct(Long id, Producto producto);
    boolean deleteProduct(Long id);
}
