package com.demo.tienda.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UsuarioDTO {
    public Long id;
    public String nombre;
    public String apellido;
    public String email;
    public String telefono;
    public String password;

    public UsuarioDTO(Long id, String nombre, String apellido, String email, String telefono) {
    }
}

