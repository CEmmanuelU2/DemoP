package com.demo.tienda.models;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "facturasdemo")
public class Factura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cliente_id", nullable = false)
    private Long clienteId;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "factura_id")
    private List<Producto> listaProductos;

    @Column(name = "total", nullable = false)
    private Double total;

    // Constructores

    public Factura() {
    }

    public Factura(Long clienteId, List<Producto> listaProductos, Double total) {
        this.clienteId = clienteId;
        this.listaProductos = listaProductos;
        this.total = total;
    }

    // Getters y setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClienteId() {
        return clienteId;
    }

    public void setClienteId(Long clienteId) {
        this.clienteId = clienteId;
    }

    public List<Producto> getListaProductos() {
        return listaProductos;
    }

    public void setListaProductos(List<Producto> listaProductos) {
        this.listaProductos = listaProductos;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }
}