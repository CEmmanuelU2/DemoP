package com.demo.tienda.models;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

// Marca esta clase como una entidad JPA que se mapea a una tabla en la base de datos
@Entity
// Especifica el nombre de la tabla en la base de datos
@Table(name = "usuariosdemo")
// Genera automáticamente métodos toString(), equals() y hashCode() usando Lombok
@ToString @EqualsAndHashCode
public class Usuario {

    // Marca el campo como la clave primaria de la entidad
    @Id
    // Indica que el valor de la clave primaria se generará automáticamente
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    // Genera los métodos getter y setter automáticamente usando Lombok
    @Getter @Setter @Column(name = "id")
    private Long id;

    // Genera los métodos getter y setter automáticamente usando Lombok
    @Getter @Setter @Column(name = "nombre")
    private String nombre;

    @Getter @Setter @Column(name = "apellido")
    private String apellido;

    @Getter @Setter @Column(name = "email")
    private String email;

    @Getter @Setter @Column(name = "telefono")
    private String telefono;

    @Getter @Setter @Column(name = "password")
    private String password;

    // Constructor sin parámetros (default constructor)
    public Usuario() {
    }

    // Constructor con parámetros
    public Usuario(Long id, String nombre, String apellido, String email, String telefono, String password) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.telefono = telefono;
        this.password = password;
    }
}