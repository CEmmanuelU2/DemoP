package com.demo.tienda.controllers;

import com.demo.tienda.dao.UsuarioDao;
import com.demo.tienda.dto.UsuarioDTO;
import com.demo.tienda.util.JWTUtil;
import com.demo.tienda.models.Usuario;
import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioDao usuarioDao;

    @Autowired
    private JWTUtil jwtUtil;

    @GetMapping
    public List<UsuarioDTO> getUsuarios(@RequestHeader(value = "Authorization") String token) throws UnauthorizedException {
        if (!validarToken(token)) {
            throw new UnauthorizedException("Token inválido");
        }
        List<Usuario> usuarios = usuarioDao.getUsuarios();
        return usuarios.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @PostMapping
    public void registrarUsuario(@RequestBody UsuarioDTO usuarioDTO) {
        Usuario usuario = convertToEntity(usuarioDTO);
        // Hash de la contraseña del usuario
        Argon2 argon2 = Argon2Factory.create(Argon2Factory.Argon2Types.ARGON2id);
        String hash = argon2.hash(1, 1024, 1, usuario.getPassword());
        usuario.setPassword(hash);
        usuarioDao.registrar(usuario);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@RequestHeader(value = "Authorization") String token, @PathVariable Long id) throws UnauthorizedException {
        if (!validarToken(token)) {
            throw new UnauthorizedException("Token inválido");
        }
        usuarioDao.eliminar(id);
    }

    private boolean validarToken(String token) {
        String usuarioId = jwtUtil.getKey(token);
        return usuarioId != null;
    }

    private UsuarioDTO convertToDTO(Usuario usuario) {
        return new UsuarioDTO(usuario.getId(), usuario.getNombre(), usuario.getApellido(), usuario.getEmail(), usuario.getTelefono());
    }

    private Usuario convertToEntity(UsuarioDTO usuarioDTO) {
        return new Usuario(usuarioDTO.getId(), usuarioDTO.getNombre(), usuarioDTO.getApellido(), usuarioDTO.getEmail(), usuarioDTO.getTelefono(), usuarioDTO.getPassword());
    }
}