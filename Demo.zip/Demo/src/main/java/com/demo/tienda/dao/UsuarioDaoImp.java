package com.demo.tienda.dao;

import com.demo.tienda.models.Usuario;
import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository  // Indica que esta clase es un repositorio de datos y debe ser gestionada por Spring
@Transactional // Marca esta clase para que las transacciones sean gestionadas automáticamente
public class UsuarioDaoImp implements UsuarioDao {

    @PersistenceContext  // Inyecta el EntityManager para manejar la persistencia de los daos
    EntityManager entityManager;

    @Override
    @Transactional  // Indica que este método debe estar en una transacción
    public List<Usuario> getUsuarios() {
        // Consulta para obtener todos los usuarios
        String query = "FROM Usuario";
        // Ejecuta la consulta y devuelve el resultado como una lista de usuarios
        return entityManager.createQuery(query).getResultList();
    }

    @Override
    public void eliminar(Long id) {
        // Busca el usuario con el ID proporcionado
        Usuario usuario = entityManager.find(Usuario.class, id);
        // Elimina el usuario encontrado
        entityManager.remove(usuario);
    }

    @Override
    public void registrar(Usuario usuario) {
        // Si el usuario ya existe, lo actualiza; si no, lo inserta
        entityManager.merge(usuario);
    }

    @Override
    public Usuario obtenerUsuarioPorCredenciales(Usuario usuario) {
        // Consulta para obtener el usuario con el email proporcionado
        String query = "FROM Usuario WHERE email = :email";
        // Ejecuta la consulta con el email como parámetro
        List<Usuario> lista = entityManager.createQuery(query)
                .setParameter("email", usuario.getEmail())
                .getResultList();

        // Si la lista está vacía, no se encontró el usuario
        if (lista.isEmpty()) {
            return null;
        }

        // Obtiene la contraseña hasheada del usuario encontrado
        String passwordHashed = lista.get(0).getPassword();

        // Crea una instancia de Argon2 para verificar la contraseña
        Argon2 argon2 = Argon2Factory.create(Argon2Factory.Argon2Types.ARGON2id);
        // Verifica si la contraseña proporcionada coincide con la contraseña hasheada
        if (argon2.verify(passwordHashed, usuario.getPassword())) {
            // Devuelve el usuario si la contraseña es correcta
            return lista.get(0);
        }
        // Devuelve null si la contraseña no es correcta
        return null;
    }
}