package com.demo.tienda.services;

import com.demo.tienda.models.Factura;
import com.demo.tienda.models.Producto;
import com.demo.tienda.repository.FacturaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@Service
public class FacturaService {

    @Autowired
    private FacturaRepository facturaRepository;

    @Autowired
    private RestTemplate restTemplate; // Para consumir otros microservicios

    private static final String CLIENTE_SERVICE_URL = "http://cliente-service";
    private static final String PRODUCTO_SERVICE_URL = "http://producto-service";

    public Factura crearFactura(Factura factura) {
        // Validar existencia del cliente
        ResponseEntity<Void> clienteResponse = restTemplate.getForEntity(CLIENTE_SERVICE_URL + "/clientes/" + factura.getClienteId(), Void.class);
        if (clienteResponse.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException("Cliente no encontrado");
        }

        // Validar y actualizar stock de productos
        for (Producto producto : factura.getListaProductos()) {
            ResponseEntity<Producto> productoResponse = restTemplate.getForEntity(PRODUCTO_SERVICE_URL + "/productos/" + producto.getId(), Producto.class);
            if (productoResponse.getStatusCode() != HttpStatus.OK) {
                throw new RuntimeException("Producto no encontrado");
            }
            Producto productoActual = productoResponse.getBody();
            if (productoActual.getStock() < producto.getStock()) {
                throw new RuntimeException("Stock insuficiente para el producto: " + producto.getId());
            }
            // Actualizar stock del producto
            productoActual.setStock(productoActual.getStock() - producto.getStock());
            restTemplate.put(PRODUCTO_SERVICE_URL + "/productos/" + producto.getId(), productoActual);
        }

        // Calcular total
        double total = factura.getListaProductos().stream()
                .mapToDouble(p -> p.getPrecio() * p.getStock())
                .sum();
        factura.setTotal(total);

        // Guardar factura
        return facturaRepository.save(factura);
    }
}
