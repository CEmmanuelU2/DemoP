package com.demo.tienda.dao;

import com.demo.tienda.models.Usuario;

import java.util.List;
//data access object (dao)
public interface UsuarioDao {

    // Método para obtener una lista de todos los usuarios
    List<Usuario> getUsuarios();

    // Método para eliminar un usuario basado en su ID
    void eliminar(Long id);

    // Método para registrar un nuevo usuario
    void registrar(Usuario usuario);

    // Método para obtener un usuario basado en sus credenciales (por ejemplo, usuario y contraseña)
    Usuario obtenerUsuarioPorCredenciales(Usuario usuario);
}