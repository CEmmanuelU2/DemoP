document.addEventListener("DOMContentLoaded", function() {
    fetchProducts();
});

function fetchProducts() {
    fetch('/api/products')
        .then(response => response.json())
        .then(products => {
            let container = document.querySelector('.row');
            container.innerHTML = ''; // Clear previous content
            products.forEach(product => {
                let card = document.createElement('div');
                card.className = 'col mb-5';
                card.innerHTML = `
                    <div class="card h-100">
                        <img class="card-img-top" src="${product.imagen || 'https://dummyimage.com/450x300/dee2e6/6c757d.jpg'}" alt="${product.nombre}" />
                        <div class="card-body p-4">
                            <div class="text-center">
                                <h5 class="fw-bolder">${product.nombre}</h5>
                                <p>${product.descripcion}</p>
                                <p>$${product.precio.toFixed(2)}</p>
                                <p>Stock: ${product.stock}</p>
                            </div>
                        </div>
                        <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                            <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">Add to cart</a></div>
                        </div>
                    </div>
                `;
                container.appendChild(card);
            });
        })
        .catch(error => console.error('Error fetching products:', error));
}