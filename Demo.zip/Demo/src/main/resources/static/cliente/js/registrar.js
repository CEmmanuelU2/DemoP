document.addEventListener('DOMContentLoaded', function() {
    // Puedes agregar código aquí que quieras ejecutar cuando el DOM esté completamente cargado
});

async function registrarUsuario(event) {
    event.preventDefault(); // Prevenir el envío por defecto del formulario

    let nombre = document.getElementById('nombre').value;
    let apellido = document.getElementById('apellido').value;
    let email = document.getElementById('email').value;
    let telefono = document.getElementById('telefono').value;
    let password = document.getElementById('password').value;
    let repetirPassword = document.getElementById('repetirPassword').value;

    if (password !== repetirPassword) {
        alert('La contraseña que escribiste es diferente.');
        return;
    }

    try {
        const response = await fetch('http://localhost:8080/api/usuarios', { // Cambia a tu URL real de backend
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('token') // JWT para autenticación
            },
            body: JSON.stringify({ nombre, apellido, email, telefono, password })
        });

        if (response.ok) {
            alert("La cuenta fue creada con éxito!");
            window.location.href = 'login.html'; // Redirige al usuario a la página de inicio de sesión
        } else {
            alert("Hubo un problema al registrar el usuario.");
        }
    } catch (error) {
        console.error('Error al registrar usuario:', error);
    }
}

document.getElementById('registrar-form').addEventListener('submit', registrarUsuario);