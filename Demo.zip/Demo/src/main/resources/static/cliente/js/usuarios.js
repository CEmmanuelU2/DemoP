$(document).ready(function() {
    // Llama a las funciones para cargar usuarios y actualizar el email del usuario al cargar la página
    cargarUsuarios();
    actualizarEmailDelUsuario();
});

// Función para actualizar el email del usuario en el DOM
function actualizarEmailDelUsuario() {
    // Actualiza el contenido del elemento con el ID 'txt-email-usuario' con el email almacenado en localStorage
    const emailElement = document.getElementById('txt-email-usuario');
    if (emailElement) {
        emailElement.textContent = localStorage.getItem('email') || 'No disponible';
    }
}




// Función para cargar usuarios desde el servidor y mostrarlos en la tabla
async function cargarUsuarios() {
    try {
        const response = await fetch('http://localhost:8080/api/usuarios', { // Cambia esto a tu URL de backend real
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('token') // Asumiendo que usas JWT para autenticación
            }
        });

        if (!response.ok) {
            throw new Error('Error al obtener los usuarios.');
        }

        const usuarios = await response.json(); // Convierte la respuesta en JSON

        let tbody = document.querySelector('#usuarios-table tbody');
        tbody.innerHTML = ''; // Limpia la tabla antes de llenarla

        usuarios.forEach(usuario => {
            let fila = `
                <tr>
                    <td>${usuario.id}</td>
                    <td>${usuario.nombre}</td>
                    <td>${usuario.apellido}</td>
                    <td>${usuario.email}</td>
                    <td>${usuario.telefono}</td>
                    <td>${usuario.password}</td> <!-- Por seguridad, considera no mostrar esto -->
                </tr>
            `;
            tbody.innerHTML += fila;
        });

    } catch (error) {
        console.error('Error al cargar usuarios:', error);
    }
}

// Llama a la función cuando el documento esté listo
document.addEventListener('DOMContentLoaded', function() {
    cargarUsuarios();
});





// Función para obtener los headers necesarios para las solicitudes
function getHeaders() {
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': localStorage.getItem('token') || ''
    };
}

// Función para eliminar un usuario
async function eliminarUsuario(id) {
    if (!confirm('¿Desea eliminar este usuario?')) {
        return;
    }

    try {
        const response = await fetch('api/usuarios/' + id, {
            method: 'DELETE',
            headers: getHeaders()
        });

        if (response.ok) {
            // Recargar la lista de usuarios sin recargar la página
            cargarUsuarios();
        } else {
            const errorText = await response.text();
            alert('No se pudo eliminar el usuario: ' + errorText);
        }
    } catch (error) {
        console.error('Error al eliminar usuario:', error);
        alert('Hubo un error al intentar eliminar el usuario.');
    }
}