$(document).ready(function() {
  // Puedes agregar código aquí que quieras ejecutar cuando el DOM esté completamente cargado
});

async function iniciarSesion() {
  // Recoge los datos del formulario
  let datos = {
    email: document.getElementById('txtEmail').value,
    password: document.getElementById('txtPassword').value
  };

  try {
    // Realiza la solicitud al servidor
    const response = await fetch('api/login', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(datos)
    });

    // Verifica si la respuesta fue exitosa
    if (!response.ok) {
      throw new Error(`Error en la solicitud: ${response.status} ${response.statusText}`);
    }

    // Obtiene la respuesta en texto
    const token = await response.text();

    // Maneja la respuesta del servidor
    if (token !== 'FAIL') {
      // Guarda el token y el email en localStorage
      localStorage.setItem('token', token);
      localStorage.setItem('email', datos.email);

      // Redirige al usuario a la página de usuarios
      window.location.href = 'usuarios.html';
    } else {
      alert("Las credenciales son incorrectas. Por favor intente nuevamente.");
    }
  } catch (error) {
    // Manejo de errores
    console.error('Error:', error);
    alert("Hubo un problema con la solicitud. Por favor, intente nuevamente.");
  }
}